package src.main.java.GlobalExceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.*;

public class InterfaceAndSortingPractice {

    @FunctionalInterface
    public interface Print{
        public void printString(String a, String b);
    }


    public static class NewRunnable implements Runnable {
        public NewRunnable(String a) {
            System.out.println(a);
        }

        @Override
        public void run() {

        }
    }

    public static void main(String args[]) {
        try {


            Print print = (a, b)->{
                System.out.println(a+" "+b);
            };
            print.printString("Hello","World");

            Runnable runnable = () -> {
                System.out.println("thread");
            };

            Thread thread = new Thread(runnable);
            thread.start();

            NewRunnable newRunnable1 = new NewRunnable("Thread 1");
            NewRunnable newRunnable2 = new NewRunnable("Thread 2");
            Thread thread1 = new Thread(newRunnable1);
            Thread thread2 = new Thread(newRunnable2);
            thread1.start();
            thread2.start();

            List<Integer> list = new ArrayList<>(Arrays.asList(2,7,3,5,0,7,6,1));
            Comparator<Integer> ascending = (a, b)-> Integer.compare(a,b);
            Collections.sort(list, ascending);
            System.out.println(list);

            Comparator<Integer> descending = (d, c) -> Integer.compare(c, d);
            Collections.sort(list, descending);
            System.out.println(list);

        } catch (AccountNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    class AccountNotFoundException extends RuntimeException{
        public AccountNotFoundException(String id){
            super("account not found for id: " + id);
        }
    }
}
