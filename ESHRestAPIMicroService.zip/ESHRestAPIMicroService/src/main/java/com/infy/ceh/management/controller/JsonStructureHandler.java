package com.infy.ceh.management.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class JsonStructureHandler {
    private static final ObjectMapper mapper = new ObjectMapper(); // Reuse the ObjectMapper
    private static final Map<Integer, Integer> jsonStructureIndex = new HashMap<>(); // Map to store hash and index

    public static void main(String[] args) throws Exception {
        String jsonFormat1 = "{ \"name\": \"John\", \"age\": 30, \"address\": { \"street\": \"123 Main St\", \"city\": \"New York\" } }";
        String jsonFormat2 = "{ \"product\": \"Laptop\", \"price\": 1000, \"specs\": { \"processor\": \"Intel\", \"ram\": \"16GB\" } }";
        String incomingJson = "{ \"name\": \"Jane\", \"age\": 25, \"address\": { \"treet\": \"456 Maple Ave\", \"city\": \"San Francisco\" } }";

        JsonStructureHandler handler = new JsonStructureHandler();

        // Store the keys-only structures' hashes and index them
        handler.storeJsonKeysStructure(jsonFormat1, 1); // Index 1
        handler.storeJsonKeysStructure(jsonFormat2, 2); // Index 2

        // Compare the incoming JSON structure's hash with stored hashes and get the index
        Integer matchingIndex = handler.compareJsonKeysStructure(incomingJson);
        if (matchingIndex != null) {
            System.out.println("The incoming JSON structure matches with stored format at index: " + matchingIndex);
        } else {
            System.out.println("No matching format found for the incoming JSON structure.");
        }
    }

    // Method to store the hash of JSON keys-only structure and index it
    public void storeJsonKeysStructure(String json, int index) throws Exception {
        JsonNode keysOnlyNode = extractKeys(mapper.readTree(json));
        int hash = keysOnlyNode.hashCode(); // Calculate the hash of the keys-only structure
        jsonStructureIndex.put(hash, index); // Store the hash and its corresponding index
    }

    // Method to compare the incoming JSON structure's hash with stored hashes and return the matching index
    public Integer compareJsonKeysStructure(String jsonToCompare) throws Exception {
        JsonNode keysOnlyTreeToCompare = extractKeys(mapper.readTree(jsonToCompare));
        int compareHash = keysOnlyTreeToCompare.hashCode(); // Calculate the hash of the keys-only structure
        return jsonStructureIndex.get(compareHash); // Return the matching index, or null if no match is found
    }

    // Helper method to extract only keys from the JSON structure, including arrays
    private JsonNode extractKeys(JsonNode node) {
        if (node.isObject()) {
            ObjectNode keysOnlyNode = mapper.createObjectNode();

            Iterator<String> fieldNames = node.fieldNames();
            while (fieldNames.hasNext()) {
                String fieldName = fieldNames.next();
                JsonNode childNode = node.get(fieldName);
                if (childNode.isObject() || childNode.isArray()) {
                    keysOnlyNode.set(fieldName, extractKeys(childNode)); // Recursive call for nested objects or arrays
                } else {
                    keysOnlyNode.put(fieldName, ""); // Storing only key names, values are empty
                }
            }

            return keysOnlyNode;
        } else if (node.isArray()) {
            ArrayNode keysOnlyArray = mapper.createArrayNode();

            for (JsonNode arrayElement : node) {
                keysOnlyArray.add(extractKeys(arrayElement)); // Recursive call for each element in the array
            }

            return keysOnlyArray;
        }

        return node;
    }
}
