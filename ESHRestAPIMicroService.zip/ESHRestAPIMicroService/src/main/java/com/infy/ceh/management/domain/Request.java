package com.infy.ceh.management.domain;

import java.util.Date;

public class Request {
    private Date createDate;
    private String dataType;
    private int jsonMetadataTypeId;
    private String reqName;
    private String jsonTextData;
    private boolean dataIdentifier;
    private String status;

    // Getters and Setters

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public int getJsonMetadataTypeId() {
        return jsonMetadataTypeId;
    }

    public void setJsonMetadataTypeId(int jsonMetadataTypeId) {
        this.jsonMetadataTypeId = jsonMetadataTypeId;
    }

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getJsonTextData() {
        return jsonTextData;
    }

    public void setJsonTextData(String jsonTextData) {
        this.jsonTextData = jsonTextData;
    }

    public boolean isDataIdentifier() {
        return dataIdentifier;
    }

    public void setDataIdentifier(boolean dataIdentifier) {
        this.dataIdentifier = dataIdentifier;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}