package com.infy.ceh.management.service;

import org.json.JSONObject;

public interface RequestService {
    void receiveRequest(JSONObject request);
    void processRequest();
}