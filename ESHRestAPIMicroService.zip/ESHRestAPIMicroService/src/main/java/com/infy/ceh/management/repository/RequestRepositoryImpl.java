package com.infy.ceh.management.repository;

import com.infy.ceh.management.util.QueryLoader;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class RequestRepositoryImpl implements RequestRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private QueryLoader queryLoader;

    @Override
    public void saveRequest(JSONObject requestBody) throws Exception {
        try {
            System.out.println("New cycle started..........................................................................................................................");
            System.out.println(requestBody);
            String sql = queryLoader.getQuery("saveRequest");
            MapSqlParameterSource params = new MapSqlParameterSource()
                    .addValue("jsonMetadataTypeId", 1)
                    .addValue("dataType", "")
                    .addValue("reqName", requestBody.get("type"))
                    .addValue("jsonTextData", requestBody.toString())
                    .addValue("dataIdentifier", false)
                    .addValue("status", "P");
            int sdfds = namedParameterJdbcTemplate.update(sql, params);
        }
        catch (Exception e){
            throw new Exception(e);
        }
    }
}