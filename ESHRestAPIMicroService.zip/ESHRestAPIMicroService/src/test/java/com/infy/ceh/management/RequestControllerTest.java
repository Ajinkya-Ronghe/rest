package com.infy.ceh.management;

import com.infy.ceh.management.controller.RequestController;
import com.infy.ceh.management.service.RequestService;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(RequestController.class)
public class RequestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RequestService requestService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testReceiveRequest() throws Exception {
        JSONObject request = new JSONObject("{\"Test\": \"Request\"}");

        doNothing().when(requestService).receiveRequest(request);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/sendrequest")
                .contentType("application/json")
                .content("{\"reqName\": \"Test Request\"}"))
                .andExpect(status().isOk());
    }
}