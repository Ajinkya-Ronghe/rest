# Petshop Sample Microservices

This minimal multi-service repo is for testing the Failure Scout scanner.

Services:
- user-service (Node/Express)
- order-service (Python/FastAPI)

There is a docker-compose file wiring both with ports and `depends_on`.
Kubernetes manifests are included for basic kind detection.
Some intentional issues are present so the scanner reports findings:
- Dockerfiles without `USER` and `HEALTHCHECK`
- Compose file exposing ports and containing env secrets
- Config files with hardcoded tokens

Run the scanner (from repo root):
```
.venv\\Scripts\\python.exe failure_scout.py samples/petshop --offline --out-md chaos_report.md --out-json chaos_report.json
```
