from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

from failure_scout import scan_repository, to_markdown, to_json, build_ai_prompt
from ai_client import AIClient


st.set_page_config(page_title="Chaos Monkey AI - Failure Scout", layout="wide")
st.title("Chaos Monkey AI - Failure Scout")
st.caption("Analyze a microservices repo for architecture, risks, and chaos ideas.")


def analyze_repo(
    repo_path: Path,
    *,
    sample_budget: int,
    model: str = "azure/genailab-maas-gpt-4o",
):
    report = scan_repository(root=repo_path)
    # AI assistance is compulsory; use defaults from AIClient
    prompt = build_ai_prompt(report, sample_text_budget=sample_budget)
    try:
        client = AIClient(model=model)
        ai_text = client.chat(prompt)
    except Exception as e:
        ai_text = f"[AI call failed: {e}]"
    report.ai_recommendations = ai_text
    return report


with st.sidebar:
    st.header("Input")
    # Default to bundled sample if available
    sample_dir = (Path(__file__).resolve().parent / "samples" / "petshop").resolve()
    default_path = str(sample_dir if sample_dir.exists() else Path.cwd())
    repo_str = st.text_input("Repository folder", value=default_path, help="Absolute or relative path")
    st.caption("AI assistance is enabled by default and required.")
    sample_budget = st.slider("Prompt sample text budget", min_value=1000, max_value=20000, value=8000, step=500)
    run = st.button("Analyze", type="primary")


if run:
    path = Path(repo_str).resolve()
    if not path.exists() or not path.is_dir():
        st.error(f"Path not found or not a directory: {path}")
    else:
        with st.spinner("Analyzing repository..."):
            report = analyze_repo(path, sample_budget=sample_budget)
        md = to_markdown(report)

        st.subheader("Report")
        st.markdown(md)

        col1, col2 = st.columns(2)
        with col1:
            st.download_button(
                "Download Markdown",
                data=md.encode("utf-8"),
                file_name="chaos_report.md",
                mime="text/markdown",
            )
        with col2:
            j = json.dumps(to_json(report), indent=2).encode("utf-8")
            st.download_button("Download JSON", data=j, file_name="chaos_report.json", mime="application/json")

else:
    st.info("Set the repository folder in the sidebar and click Analyze.")

# Usage (terminal):
#   streamlit run streamlit_app.py
