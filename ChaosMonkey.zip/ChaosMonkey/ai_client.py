"""
AI client for the GenAI Lab gateway (primary and only provider).

Defaults:
- Base: https://genailab.tcs.in
- Path: /openai/deployments/{model}/chat/completions
- Auth header: api-key: <key>

Environment variables:
- AI_API_KEY (required unless provided to the constructor)
- AI_API_BASE (optional; defaults to https://genailab.tcs.in)
- AI_API_PATH (optional; defaults to /openai/deployments/{model}/chat/completions)
- AI_SSL_NO_VERIFY=1 (optional; disable TLS verification)
"""
from __future__ import annotations

import json
import os
from typing import Optional, Dict


class AIClient:
    def __init__(
        self,
        *,
        model: str = "azure/genailab-maas-gpt-4o",
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        api_path: Optional[str] = None,
        timeout: int = 60,
        verify_ssl: bool = True,
    ) -> None:
        self.model = model
        # Only use AI_API_KEY for this gateway
        self.api_key = api_key or os.getenv("AI_API_KEY")
        if not self.api_key:
            raise RuntimeError("AI_API_KEY not set")
        # Default to GenAI Lab gateway; allow overrides
        self.api_base = (api_base or os.getenv("AI_API_BASE") or "https://genailab.tcs.in").rstrip("/")
        self.api_path = api_path or os.getenv("AI_API_PATH") or "/openai/deployments/{model}/chat/completions"
        self.timeout = timeout
        # Honor env to disable SSL verify
        if os.getenv("AI_SSL_NO_VERIFY", "").lower() in {"1", "true", "yes"}:
            verify_ssl = False
        self.verify_ssl = verify_ssl
        # Fixed header scheme for this gateway
        self._auth_header_name = "api-key"

        # Common alias map for providers that require dated model names
        self._model_alias: Dict[str, str] = {
            "gpt-4o": "gpt-4o-2024-11-20",
            "gpt-4o-mini": "gpt-4o-mini-2024-07-18",
            "o4-mini": "o4-mini-2024-08-06",
        }

    def _build_url(self) -> str:
        path = self.api_path.replace("{model}", self.model) if "{model}" in self.api_path else self.api_path
        return f"{self.api_base}/{path.lstrip('/')}"

    def chat(self, prompt: str, *, temperature: float = 0.2, max_tokens: int = 1200) -> str:
        import urllib.request
        import urllib.error
        import ssl

        url = self._build_url()
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are a senior SRE and security engineer."},
                {"role": "user", "content": prompt},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data)
        req.add_header("Content-Type", "application/json")
        req.add_header(self._auth_header_name, self.api_key)
        context = None
        if not self.verify_ssl and self._build_url().startswith("https://"):
            context = ssl._create_unverified_context()

        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=context) as resp:  # nosec
                raw = resp.read().decode("utf-8", errors="ignore")
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore") if hasattr(e, "read") else str(e)
            # If invalid model, try alias fallback once
            if e.code == 400 and "Invalid model name" in err_body and self.model in self._model_alias:
                alias_model = self._model_alias[self.model]
                return self._retry_with_model(alias_model, prompt, temperature, max_tokens)
            raise RuntimeError(f"HTTP {e.code} calling {url}: {err_body}")
        obj = json.loads(raw)
        try:
            return obj["choices"][0]["message"]["content"].strip()
        except Exception:
            return raw[:4000]

    def _retry_with_model(self, new_model: str, prompt: str, temperature: float, max_tokens: int) -> str:
        import urllib.request
        import urllib.error
        import json as _json
        import ssl

        url = self._build_url() if "{model}" not in self.api_path else self._build_url().replace(self.model, new_model)

        payload = {
            "model": new_model if "deployments" not in self.api_path else new_model,
            "messages": [
                {"role": "system", "content": "You are a senior SRE and security engineer."},
                {"role": "user", "content": prompt},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        data = _json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data)
        req.add_header("Content-Type", "application/json")
        req.add_header(self._auth_header_name, self.api_key)
        context = None
        if not self.verify_ssl and url.startswith("https://"):
            context = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=self.timeout, context=context) as resp:  # nosec
            raw = resp.read().decode("utf-8", errors="ignore")
        obj = json.loads(raw)
        try:
            return obj["choices"][0]["message"]["content"].strip()
        except Exception:
            return raw[:4000]

    def list_models(self) -> str:
        """Fetches /v1/models for debugging, returns raw JSON string. Useful to inspect available models."""
        import urllib.request
        import urllib.error
        import ssl

        base = self.api_base
        url = f"{base}/v1/models"
        req = urllib.request.Request(url)
        req.add_header(self._auth_header_name, self.api_key)
        context = None
        if not self.verify_ssl and url.startswith("https://"):
            context = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=self.timeout, context=context) as resp:  # nosec
            return resp.read().decode("utf-8", errors="ignore")
